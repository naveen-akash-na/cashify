function showMobileNavOption() {
    let el = document.getElementById("mobile_nav_option");
    el.classList.toggle("hidden");
    el.classList.toggle("flex");
}
